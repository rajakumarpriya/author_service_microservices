//package com.dbook.book.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.stereotype.Service;
//
//import com.dbook.book.entity.Book;
//import com.dbook.book.entity.Book_Kafka;
//import com.dbook.book.repository.BookRepository;
//
//
//@Service
//public class KafkaConsumerListener {
//	
//	@Autowired
//	private BookRepository dataRepository;
//
//    private static final String TOPIC = "kafka-topic-dbook";
//
//    @KafkaListener(topics = TOPIC, groupId="group_id", containerFactory = "userKafkaListenerFactory")
//    public void consumeJson(Book_Kafka book) {
//        System.out.println("Consumed JSON Message: " + book);
//        
//        
//        Book wikimediaData = new Book();
//        
//        wikimediaData.setTitle(book.getTitle());
//       // wikimediaData.setAuthor(book.getAuthor());
//        wikimediaData.setPrice(book.getPrice());
//
//        dataRepository.save(wikimediaData);
//    }
//    
//}