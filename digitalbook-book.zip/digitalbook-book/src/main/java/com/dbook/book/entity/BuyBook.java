package com.dbook.book.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


public class BuyBook {


    private int id;
    private int bookid;
	private String readername;
	private String readermail;
	private int paymentid;
	private Date purchaseDate;
	
  
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public String getReadername() {
		return readername;
	}
	public void setReadername(String readername) {
		this.readername = readername;
	}
	public String getReadermail() {
		return readermail;
	}
	public void setReadermail(String readermail) {
		this.readermail = readermail;
	}
	
	public int getPaymentid() {
		return paymentid;
	}
	public void setPaymentid(int paymentid) {
		this.paymentid = paymentid;
	}
	public Date getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	@Override
	public String toString() {
		return "BuyBook [id=" + id + ", bookid=" + bookid + ", readername=" + readername + ", readermail=" + readermail
				+ ", paymentid=" + paymentid +  ", purchaseDate=" + purchaseDate + "]";
	}
	public BuyBook() {
		// TODO Auto-generated constructor stub
	}
	
	public BuyBook(int bookid, String readername, String readermail,int paymentid, Date purchaseDate) {
		this.bookid = bookid;
		this.readername = readername;
		this.readermail = readermail;
		this.paymentid= paymentid;
		this.purchaseDate= purchaseDate;
	}
	public BuyBook(int id, int bookid, String readername, String readermail,int paymentid, Date purchaseDate) {
		super();
		this.id = id;
		this.bookid = bookid;
		this.readername = readername;
		this.readermail = readermail;
		this.paymentid= paymentid;
		this.purchaseDate= purchaseDate;
	}
	
	
	
}
