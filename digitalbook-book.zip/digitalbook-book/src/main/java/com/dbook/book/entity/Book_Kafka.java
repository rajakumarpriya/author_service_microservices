package com.dbook.book.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Book_Kafka {

    
	
	
	@JsonProperty("FILE_LIST")
	private int id;
	private String image;
	private String title;
    private String category;
    private int price;
    private String auhtor;
    private int auhtorid;
   
	private String publisher;
    private String published_date;
   
	private String chapter;
    private String active_status;
    public Book_Kafka() {
    	
    }
    public Book_Kafka(int id, String image, String title, String category, int price, String auhtor, int auhtorid,
			String publisher, String published_date, String chapter, String active_status) {
		super();
		this.id = id;
		this.image = image;
		this.title = title;
		this.category = category;
		this.price = price;
		this.auhtor = auhtor;
		this.auhtorid = auhtorid;
		this.publisher = publisher;
		this.published_date = published_date;
		this.chapter = chapter;
		this.active_status = active_status;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public void setAuhtorid(int auhtorid) {
		this.auhtorid = auhtorid;
	}
	
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	
	public void setPublished_date(String published_date) {
		this.published_date = published_date;
	}
	
	public void setChapter(String chapter) {
		this.chapter = chapter;
	}
	public void setActive_status(String active_status) {
		this.active_status = active_status;
	}

	
   
	public int getId() {
		return id;
	}
	 public String getImage() {
			return image;
		}
	public String getTitle() {
		return title;
	}
	public String getCategory() {
		return category;
	}
	public int getPrice() {
		return price;
	}
	public String getAuhtor() {
		return auhtor;
	}
	public int getAuhtorid() {
		return auhtorid;
	}
	
	public String getPublisher() {
		return publisher;
	}
	public String getPublished_date() {
		return published_date;
	}
	public String getChapter() {
		return chapter;
	}

	public String getActive_status() {
		return active_status;
	}
	
	
	
	 @Override
		public String toString() {
			return "Book_Kafka [id=" + id + ", image=" + image + ", title=" + title + ", category=" + category + ", price="
					+ price + ", auhtor=" + auhtor + ", auhtorid=" + auhtorid + ", publisher=" + publisher
					+ ", published_date=" + published_date + ", chapter=" + chapter + ", active_status=" + active_status
					+ "]";
		}
}
