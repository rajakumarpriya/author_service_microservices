package com.dbook.book.controller;

import com.dbook.book.entity.Book;
import com.dbook.book.service.BookService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import javax.mail.internet.MimeMessage;

import java.io.File;

import javax.mail.MessagingException;

import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.ui.Model;

@RestController
@RequestMapping("/api/v1")
@RefreshScope
@CrossOrigin
public class BookController {

    @Autowired
    private BookService service;
    
    @Autowired
    private JavaMailSender mailsender;

    @PostMapping("/addBook")
    public Book addBook(@RequestBody Book book) {
        return service.saveBook(book);
    }

    @PostMapping("/addBooks")
    public List<Book> addBooks(@RequestBody List<Book> books) {
        return service.saveBooks(books);
    }

    @GetMapping("/books")
    public List<Book> findAllBooks() {
        return service.getBooks();
    }

    @GetMapping("/bookById/{id}")
    public Book findBookById(@PathVariable int id) {
        return service.getBookById(id);
    }

    @GetMapping("/book/{name}")
    public Book findBookByName(@PathVariable String name) {
        return service.getBookByName(name);
    }

    @PutMapping("/update")
    public Book updateBook(@RequestBody Book book) {
        return service.updateBook(book);
    }

    @DeleteMapping("/delete/{id}")
    public int deleteBook(@PathVariable int id) {
        return service.deleteBook(id);
    }
    
    
     @GetMapping("/searchbook") 
    // @RequestMapping(value = "/searchbook", params = "ids", method = RequestMethod.GET)
     public Book getBookSearchDetails(@RequestParam String category,
     		@RequestParam String author,
     		@RequestParam int price,@RequestParam String publisher) {
      	
  	return service.getBookSearchDetails(category,author,price,publisher);
  	   
     }
    
    
    @GetMapping("/send_text_email")
	public String sendPlainTextEmail(Model model) {
//		String from = "codejava.net@gmail.com";
//		String to = "hainatu@gmail.com";
    	
    	String to = "raajakumarmca@gmail.com";
		String from = "21rajakumar21@gmail.com";
		
		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom(from);
		message.setTo(to);
		message.setSubject("This is a plain text email");
		message.setText("Hello guys! This is a plain text email.");
		
		mailsender.send(message);
		
		model.addAttribute("message", "A plain text email has been sent");
		return "result";
	}
	
	@GetMapping("/send_html_email")
	public String sendHTMLEmail(Model model) throws MessagingException {
//		String from = "codejava.net@gmail.com";
//		String to = "hainatu@gmail.com";
		
		String to = "raajakumarmca@gmail.com";
		String from = "21rajakumar21@gmail.com";
		
		MimeMessage message = mailsender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);
		
		helper.setSubject("This is an HTML email");
		helper.setFrom(from);
		helper.setTo(to);

		boolean html = true;
		helper.setText("<b>Hey guys</b>,<br><i>Welcome to my new home</i>", html);

		mailsender.send(message);
		
		model.addAttribute("message", "An HTML email has been sent");
		return "result";		
	}
	
	@GetMapping("/send_email_attachment")
	public String sendHTMLEmailWithAttachment(Model model) throws MessagingException {
		
//		String from = "codejava.net@gmail.com";
//		String to = "hainatu@gmail.com";
		
		String to = "raajakumarmca@gmail.com";
		String from = "21rajakumar21@gmail.com";
		
		MimeMessage message = mailsender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, true);
		
		helper.setSubject("Here's your e-book");
		helper.setFrom(from);
		helper.setTo(to);
		
		helper.setText("<b>Dear friend</b>,<br><i>Please find the book attached.</i>", true);
		
		FileSystemResource file = new FileSystemResource(new File("g:\\MyEbooks\\Freelance for Programmers\\SuccessFreelance-Preview.pdf"));
		helper.addAttachment("FreelanceSuccess.pdf", file);

		mailsender.send(message);
		
		model.addAttribute("message", "An HTML email with attachment has been sent");
		return "result";		
	}
	
	@GetMapping("/send_email_inline_image")
	public String sendHTMLEmailWithInlineImage(Model model) throws MessagingException {
		
//		String from = "codejava.net@gmail.com";
//		String to = "hainatu@gmail.com";
		
		String to = "raajakumarmca@gmail.com";
		String from = "21rajakumar21@gmail.com";
		
		MimeMessage message = mailsender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, true);
		
		helper.setSubject("Here's your pic");
		helper.setFrom(from);
		helper.setTo(to);
		
		String content = "<b>Dear guru</b>,<br><i>Please look at this nice picture:.</i>"
							+ "<br><img src='cid:image001'/><br><b>Best Regards</b>"; 
		helper.setText(content, true);
		
		FileSystemResource resource = new FileSystemResource(new File("g:\\MyEbooks\\Freelance for Programmers\\images\\admiration.png"));
		helper.addInline("image001", resource);

		mailsender.send(message);
		
		model.addAttribute("message", "An HTML email with inline image has been sent");
		return "result";		
	}	
}
