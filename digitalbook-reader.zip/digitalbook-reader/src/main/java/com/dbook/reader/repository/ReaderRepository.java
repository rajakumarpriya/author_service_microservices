package com.dbook.reader.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dbook.reader.entities.BuyBook;
@Repository
public interface ReaderRepository extends JpaRepository<BuyBook,Integer> {
   // Author findByUsername(String username);
	BuyBook findByReadername(String readername); // select name from buybook;
	BuyBook findByIdAndReadernameAndReadermail(int id,String readername,String readermail);
}

