package com.dbook.reader.entities;

public class Book_Kafka {

	
	
	
	
	
	
	
	private int id;
	private String image;
	private String title;
    private String category;
    private int price;
    private String auhtor;
    private int auhtorid;
   
	private String publisher;
    private String published_date;
    private String chapter;
    private String active_status;
    private Book book;
    
    public Book_Kafka() {
    	
    }
    public Book_Kafka(int id, String image, String title, String category, int price, String auhtor, int auhtorid,
			String publisher, String published_date, String chapter, String active_status,Book book) {
		super();
		this.id = id;
		this.image = image;
		this.title = title;
		this.category = category;
		this.price = price;
		this.auhtor = auhtor;
		this.auhtorid = auhtorid;
		this.publisher = publisher;
		this.published_date = published_date;
		this.chapter = chapter;
		this.active_status = active_status;
		this.book=book;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getAuhtor() {
		return auhtor;
	}
	public void setAuhtor(String auhtor) {
		this.auhtor = auhtor;
	}
	public int getAuhtorid() {
		return auhtorid;
	}
	public void setAuhtorid(int auhtorid) {
		this.auhtorid = auhtorid;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getPublished_date() {
		return published_date;
	}
	public void setPublished_date(String published_date) {
		this.published_date = published_date;
	}
	public String getChapter() {
		return chapter;
	}
	public void setChapter(String chapter) {
		this.chapter = chapter;
	}
	public String getActive_status() {
		return active_status;
	}
	public void setActive_status(String active_status) {
		this.active_status = active_status;
	}
    public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	@Override
	public String toString() {
		return "Book_Kafka [id=" + id + ", image=" + image + ", title=" + title + ", category=" + category + ", price="
				+ price + ", auhtor=" + auhtor + ", auhtorid=" + auhtorid + ", publisher=" + publisher
				+ ", published_date=" + published_date + ", chapter=" + chapter + ", active_status=" + active_status
				+ ", book=" + book + "]";
	}
	
	
	
}
