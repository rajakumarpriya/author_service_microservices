//package com.dbook.reader.services;
//
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.stereotype.Service;
//
//import com.dbook.reader.entities.*;
//
//@Service
//public class KafkaConsumerListener {
//
//    private static final String TOPIC = "kafka-topic-dbook";
//
//    @KafkaListener(topics = TOPIC, groupId="group_id", containerFactory = "userKafkaListenerFactory")
//    public void consumeJson(Book_Kafka book) {
//        System.out.println("Consumed JSON Message: " + book);
//    }
//    
//}