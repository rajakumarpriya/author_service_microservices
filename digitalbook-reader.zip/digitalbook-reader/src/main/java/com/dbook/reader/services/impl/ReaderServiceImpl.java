package com.dbook.reader.services.impl;



import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dbook.reader.entities.Book;
import com.dbook.reader.entities.Book_Kafka;
import com.dbook.reader.entities.BuyBook;
import com.dbook.reader.repository.ReaderRepository;
import com.dbook.reader.services.ReaderService;
import reactor.core.publisher.Mono;

@Service
public class ReaderServiceImpl implements ReaderService {

	@Autowired ReaderRepository readerRepository;
	@Autowired ApiCall apiCall;   // using restTemplate
	@Autowired ApiCallUsingWebClient apiCallUsingWebClient; // using webClient
	
	
	
	  //public BuyBook buybook(BuyBook book);
	   // public List<BuyBook> getAllPurBooks();
	  //  public BuyBook getAllPurPayBooks(int id);
	
	public Book_Kafka getById(int id) {
		// getting student from table by passing id
		BuyBook s = readerRepository.findById(id).orElse(null);
		
		//getting course from course microservice by call API
		Book course = apiCall.getCourseDetails(s.getId());
		
		Book_Kafka sd = new Book_Kafka();
		BeanUtils.copyProperties(s, sd);
		sd.setBook(course);
		
		
		return sd;
	}
	
	public Book_Kafka getByIdUsingWebClient(int id) {
		// getting student from table by passing id
		BuyBook s = readerRepository.findById(id).orElse(null);
		
		//getting course from course microservice by call API
		Mono<Book> courseMono = apiCallUsingWebClient.getCourseDetails(s.getId());
		Book course = courseMono.block();
		
		Book_Kafka sd = new Book_Kafka();
		// copying properties from student to studentdetail object
		BeanUtils.copyProperties(s, sd);
		sd.setBook(course);
		return sd;
	}
	public Book getSearchUsingWebClient(String category, String author, int price, String publisher) {
		
		BuyBook s = new BuyBook();
		//getting course from course microservice by call API
				Mono<Book> courseMono = apiCallUsingWebClient.getBookSearchDetails(category,  author,  price,  publisher);
				Book course = courseMono.block();
				
				Book_Kafka sd = new Book_Kafka();
				// copying properties from student to studentdetail object
				//BeanUtils.copyProperties(s, sd);
				//sd.setBook(course);
				return course;
	}
	public BuyBook makeAction(int id, String clientName,String clientSurname) {
		return readerRepository.findByIdAndReadernameAndReadermail(id,  clientName,clientSurname);

	}

	List<BuyBook> getAllPurBooks1(){
		return  readerRepository.findAll();
	}

	public BuyBook buybook(BuyBook buybook) {
		return readerRepository.save(buybook);
	}

	@Override
	public List<BuyBook> getAllPurBooks() {
		// TODO Auto-generated method stub
		return  readerRepository.findAll();
	}

	@Override
	public BuyBook getAllPurPayBooks(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BuyBook getByReadername(String readername) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int deleteBook(int id) {
		// TODO Auto-generated method stub
		readerRepository.deleteById(id);
	        return  id;
	}

	
}