package com.dbook.reader.services.impl;





import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.client.loadbalancer.reactive.ReactorLoadBalancerExchangeFilterFunction;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.dbook.reader.entities.Book;

import reactor.core.publisher.Mono;

@Service
public class ApiCallUsingWebClient {
  private static final Logger logger = LoggerFactory.getLogger(ApiCallUsingWebClient.class);
	
  private final WebClient.Builder loadBalancedWebClientBuilder;

  private static final String courseMisroserviceBaseURL = 
			"http://book-service";
  
  public ApiCallUsingWebClient(WebClient.Builder webClientBuilder,
      ReactorLoadBalancerExchangeFilterFunction lbFunction) {
    this.loadBalancedWebClientBuilder = webClientBuilder;
  }
//(courseMisroserviceBaseURL + "/course/id?id=" + courseId)
  //@RequestParam int id
  public Mono<Book> getCourseDetails(int courseId) {
	logger.info("calling course microservice API using Web-Client");
		System.out.println(courseMisroserviceBaseURL+"courseMisroserviceBaseURL");
    return loadBalancedWebClientBuilder.build().get().uri
    		(courseMisroserviceBaseURL + "/api/v1/bookById/" + courseId)
        .retrieve().bodyToMono(Book.class);
   }
  public Mono<Book> getBookSearchDetails(String category, String author, int price,String publisher) {
		logger.info("calling course microservice API using Web-Client");
			System.out.println(courseMisroserviceBaseURL+"courseMisroserviceBaseURL");
	    return loadBalancedWebClientBuilder.build().get().uri
	    		(courseMisroserviceBaseURL + "/api/v1/searchbook?category="+category+"&author=" +author+"&price="+price+"&publisher="+publisher)
	        .retrieve().bodyToMono(Book.class);
	   }

}