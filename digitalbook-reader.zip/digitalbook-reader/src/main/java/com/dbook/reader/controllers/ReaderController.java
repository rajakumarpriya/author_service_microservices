package com.dbook.reader.controllers;

import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.dbook.reader.entities.Book;
import com.dbook.reader.entities.Book_Kafka;
import com.dbook.reader.entities.BuyBook;
import com.dbook.reader.entities.ReaderBook;
import com.dbook.reader.entities.RequiredResponse;
import com.dbook.reader.exception.ReaderException;
import com.dbook.reader.services.ReaderService;
import com.dbook.reader.repository.ReaderRepository;


@RestController
// @CrossOrigin(origins = {"https://hoppscotch.io"})
@CrossOrigin
@RequestMapping("/api/v1")
@RefreshScope
public class ReaderController {
    
    
    @Autowired
	private RestTemplate restTemplate;
    
    @Autowired
    private ReaderService service;
    
    @Autowired
    private ReaderRepository repo;
    
//    @Autowired
//	KafkaTemplate<String,BuyBook> kt;

  
    //http://localhost:9053/api/v1/buyPayload 
    //save purchased book from reader
    @PostMapping("/buyPayload")
    public BuyBook addPurchasedBook(@RequestBody BuyBook buybook) {
        return service.buybook(buybook);
    }
    
    
    //http://localhost:9053/api/v1/searchbook
    ///searching all book by reader using REST TEMPLATE
    @GetMapping("/searchbook")   
	public List<ReaderBook> getHerosFromDb(){
		
		HttpHeaders headers = null;
		ResponseEntity<List<ReaderBook>> responseEntity = restTemplate.exchange(
			//"lb://HEROS-APP/api/v1/movies",
			"http://localhost:9052/api/v1/books",
			HttpMethod.GET,
			new HttpEntity(null, headers),
			new ParameterizedTypeReference<List<ReaderBook>>() {}
		);
		//System.out.println("test"+responseEntity.getBody());
		return responseEntity.getBody();
	}
    
    
    //http://localhost:9053/api/v1/purchasedBooks
    // reader purchased all books 
    @GetMapping("/purchasedBooks")
    public List<BuyBook> findAllPurBooks() throws ReaderException {
    	List<BuyBook> buybooks= service.getAllPurBooks();
    	return buybooks;
    }
    
    @DeleteMapping("/delete/{id}")
    public int deleteBook(@PathVariable int id) {
        return service.deleteBook(id);
    }
    //http://localhost:9053/api/v1/purchasedBooksval/2
	// reader can search book by specific book from purchased book
    //Exception handled by this method
    @SuppressWarnings("unlikely-arg-type")
    @GetMapping("/purchasedBooksval1/{purchasedbookid}")
    public BuyBook findAllPurchBooks(@PathVariable Integer purchasedbookid) throws ReaderException { 
    	BuyBook b1=null;
	    b1=service.getAllPurPayBooks(purchasedbookid);
	        if (b1!=null)
	            b1=b1;
	        else
	            throw new ReaderException("Null pointer Exception");
	    return b1;
	    }
    @GetMapping("/purchasedBooksval/{purchasedbookid}") 
   public Book_Kafka getByIdUsingWebClient(@PathVariable int purchasedbookid) {
    	
	return service.getByIdUsingWebClient(purchasedbookid);
	   
   }
    
    @GetMapping("/purchasedBooksvalAPi/{purchasedbookid}") 
    public Book_Kafka getById(@PathVariable int purchasedbookid) {
     	
 	return service.getByIdUsingWebClient(purchasedbookid);
 	   
    }
   // @GetMapping("/searchbook/{purchasedbookid}") 
//    @GetMapping("/div") // /div?x=6.3&y=2.1
//	@ResponseBody
//	public int process(@RequestParam int x, @RequestParam int y) {
//		return x/y;
//	}
    @RequestMapping("/searchbook1") 
   // @RequestMapping(value = "/searchbook", params = "ids", method = RequestMethod.GET)
    public Book getBookSearchDetails(@RequestParam String category,
    		@RequestParam String author,
    		@RequestParam int price,@RequestParam String publisher) {
     	
 	return service.getSearchUsingWebClient(category,author,price,publisher);
 	   
    }
    //localhost:8080/makeAction?loanId=1&clientName=Stive&clientSurname=Wassabi

    @RequestMapping(value = "/makeAction")
    public BuyBook makeLoan(@RequestParam("id")int loan_id,
                           @RequestParam("readername")String clientName,
                           @RequestParam("readermail")String clientSurname ) throws Exception {
        return service.makeAction(loan_id,clientName,clientSurname);
    }
    //getBookSearchDetails
     
    
    //public Book_Kafka getById(int id);
//    @GetMapping("/purchasedBook/")
//    public List<BuyBook> findAllPurBooks() throws ReaderException {
//    	List<BuyBook> buybooks= service.getAllPurBooks();
//    	return buybooks;
//    }
    
//    @PostMapping(path="/buyPayload",consumes = "application/json", produces = "application/json")
//    public BuyBook buyBook(@RequestBody BuyBook book) {
//        //return service.buyBook(book);
//        
//        kt.send("kafka-messages",book);
//        BuyBook buybook = service.buyBook(book);
//        System.out.println("Added reader"+buybook.toString());
//	    return buybook;
//    }
    
    
   
    
    // reader cancel book 48 hrs from purcahsed book
    // and aslo active status 

  
    
//    @GetMapping(path = "/purchasedBooks/{id}")
//	public ResponseEntity<RequiredResponse> getAllDadaBasedonCenterId(@PathVariable Integer id){
//    	RequiredResponse requiredResponse =  new RequiredResponse();
//		//1st get vaccination center detail
//    	BuyBook center  = repo.findById(id).get();
//    	System.out.println(center+"center");
//		requiredResponse.setBuyBook(center);
//		
//		// then get all citizen registerd to vaccination center
//		
//		List<Book> listOfBooks = restTemplate.getForObject("http://localhost:9052/api/v1/bookById/"+id, List.class);
//		requiredResponse.setBooks(listOfBooks);
//		
//		//return listOfCitizens.getBody();
//		return new ResponseEntity<RequiredResponse>(requiredResponse, HttpStatus.OK);
//	}
    
    
    @GetMapping("/searchbook/{data}")
	public List<ReaderBook> getBookDetailDb(@PathVariable int data){
		
		HttpHeaders headers = null;
		
		ResponseEntity<List<ReaderBook>> responseEntity = restTemplate.exchange(
			//"lb://HEROS-APP/api/v1/movies",
			"http://localhost:9052/api/v1/bookById/"+data,
			HttpMethod.GET,
			new HttpEntity(null, headers),
			new ParameterizedTypeReference<List<ReaderBook>>() {}
		);
		return responseEntity.getBody();
	}
    
    

}
