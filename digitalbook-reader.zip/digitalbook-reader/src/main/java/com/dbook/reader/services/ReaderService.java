package com.dbook.reader.services;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.dbook.reader.entities.Book;
import com.dbook.reader.entities.Book_Kafka;
import com.dbook.reader.entities.BuyBook;
import java.util.List;

@Service
public interface ReaderService {
    
    
    public BuyBook buybook(BuyBook book);
    public List<BuyBook> getAllPurBooks();
    public BuyBook getAllPurPayBooks(int id);
    public int deleteBook(int id);
      
    
    public Book_Kafka getById(int id);
	//BuyBook getByName(String name);
//	boolean save(Student student);
//	boolean delete(int id);
//	boolean update(Student student);
	public Book_Kafka getByIdUsingWebClient(int id);
	//category,author,price,publisher
	public Book getSearchUsingWebClient(String category, String author, int price, String publisher);
	public BuyBook getByReadername(String readername);
	public BuyBook makeAction(int loan_id, String clientName, String clientSurname);
    

   
//	public BuyBook buyBook(BuyBook book) {
//		// TODO Auto-generated method stub
//		return repository.save(book);
//	}
//
//    public List<BuyBook> getAllPurBooks() {
//        return repository.findAll();
//    }
//
//    public BuyBook getAllPurPayBooks(int id) {
//        return  repository.findById(id).orElse(null);
//    }
    
    
    
    
    
//
//    public Author getAuthorByName(String name) {
//        return repository.findByUsername(name);
//    }
//
//    public Author updateAuthor(Author author) {
//        Author existingAuthor = repository.findById(author.getId()).orElse(null);
//        existingAuthor.setUsername(author.getUsername());
//        existingAuthor.setPassword(author.getPassword());
//        existingAuthor.setRole(author.getRole());
//        return repository.save(existingAuthor);
//    }


}
