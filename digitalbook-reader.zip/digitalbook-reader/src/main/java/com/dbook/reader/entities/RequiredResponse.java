package com.dbook.reader.entities;
import java.util.List;

public class RequiredResponse {


	
	private BuyBook buybook;
	private List<Book> books;
	public void setBooks(List<Book> listOfBooks) {
		// TODO Auto-generated method stub
		
	}
	public void setBuyBook(BuyBook buybook) {
		// TODO Auto-generated method stub
		
	}
	

}

