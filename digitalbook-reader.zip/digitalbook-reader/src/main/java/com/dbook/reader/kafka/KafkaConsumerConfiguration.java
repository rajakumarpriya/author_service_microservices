//package com.dbook.reader.kafka;
//
//import java.util.HashMap;
//import java.util.Map;
//
//import org.apache.kafka.clients.consumer.ConsumerConfig;
//import org.apache.kafka.common.serialization.StringDeserializer;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.
//import org.apache.kafka.clients.config.ConcurrentKafkaListenerContainerFactory;
//import org.springframework.kafka.core.ConsumerFactory;
//import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
//import org.springframework.kafka.support.serializer.JsonDeserializer;
//
//import org.apache.kafka.clients.producer.KafkaProducer;
//import org.apache.kafka.clients.producer.ProducerConfig;
//import org.apache.kafka.clients.producer.ProducerRecord;
//
//import com.dbook.reader.entities.*;
//
//@EnableKafka
//@Configuration
//public class KafkaConsumerConfiguration {
//
//    @Bean
//    public ConsumerFactory<String, Book_Kafka> userConsumerFactory() {
//        Map<String, Object> config = new HashMap<>();
//
//        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
//        config.put(ConsumerConfig.GROUP_ID_CONFIG, "group_id");
//        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
//        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
//        
//        
//        
//        
//        props.put("bootstrap.servers", "broker1:9092,broker2:9092");
//        props.put("group.id", "CountryCounter");
//        props.put("key.deserializer",
//            "org.apache.kafka.common.serialization.StringDeserializer");
//        props.put("value.deserializer",
//            "org.apache.kafka.common.serialization.StringDeserializer");
//        
//        
//        return new DefaultKafkaConsumerFactory<>(config, new StringDeserializer(),
//                new JsonDeserializer<>(Book_Kafka.class));
//    }
//
//    @Bean
//    public ConcurrentKafkaListenerContainerFactory<String, Book_Kafka> userKafkaListenerFactory() {
//        ConcurrentKafkaListenerContainerFactory<String, Book_Kafka> factory = new ConcurrentKafkaListenerContainerFactory<>();
//        factory.setConsumerFactory(userConsumerFactory());
//        return factory;
//    }
//
//}
