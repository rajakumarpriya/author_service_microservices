package com.dbook.reader.exception.handler;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.dbook.reader.exception.ReaderException;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(ReaderException.class)
	public ResponseEntity<?> handleException(ReaderException e) {
		return ResponseEntity.ok(new ErrorResponse(e.getMessage(), e.getClass().toString()));
	}
}
